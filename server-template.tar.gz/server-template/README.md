# AVA Portfolio Manager Server Template

This is a minimal template version of the AVA Portfolio Manager AI Agent server. Use this template to quickly spin up a new instance with the core functionality.

## Features

- Minimal agent system with essential components
- WebSocket-based communication
- AI provider integration (Groq/OpenAI)
- Basic swap agent for DeFi functionality
- Task manager for handling user requests

## Getting Started

### Prerequisites

- Node.js 18+ or Bun runtime
- API keys for AI providers (Groq/OpenAI)

### Installation

1. Clone this template repository
```bash
git clone <repository-url> my-ava-project
cd my-ava-project
```

2. Install dependencies
```bash
npm install
# or with bun
bun install
```

3. Create a `.env` file based on the provided `.env.example`
```bash
cp .env.example .env
```

4. Edit the `.env` file with your own API keys and configuration

### Running the Server

```bash
# Development mode
npm run dev
# or
bun run dev

# Production mode (after building)
npm run build
npm start
```

## Architecture

The template includes a minimal version of the full AVA architecture:

- `index.ts`: Main entry point for the server
- `agents/`: Contains agent implementations
  - `task-manager/`: Basic task manager agent
  - `SwapAgent.ts`: Simple swap agent for handling trading operations
- `services/`: Core services
  - `ai/`: AI provider integrations
  - `0x/`: 0x protocol integration for swaps
- `comms/`: Communication layer with WebSocket event bus

## Adding Custom Agents

To add custom agents:

1. Create a new agent in the `agents/` directory
2. Implement the agent interface from `agents/agent.ts`
3. Register your agent in `agents/index.ts`

## Customizing the Server

- Edit `src/index.ts` to add or remove functionality
- Customize environment variables in `.env`
- Add additional services in the `services/` directory

## License

[Your License]
