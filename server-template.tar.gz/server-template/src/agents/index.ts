import { Account } from 'viem';
import { EventBus } from '../comms/event-bus';
import { TaskManagerAgent } from './task-manager';

/**
 * Register agents with the system
 * @param eventBus EventBus instance for inter-agent communication
 * @param account Wallet account for blockchain interactions
 * @param aiProvider AI provider for agent intelligence
 * @returns Object containing all initialized agents
 */
export function registerAgents(
  eventBus: EventBus,
  account: Account,
  aiProvider: any
) {
  console.log('Registering agents with event bus');
  
  // Initialize Task Manager Agent
  const taskManagerAgent = new TaskManagerAgent(eventBus, aiProvider);
  console.log('Task Manager Agent initialized');

  // Return the agents
  return {
    taskManagerAgent,
  };
}