// // src/index.ts
// import { serve } from "@hono/node-server";
// import { app } from "./app";
// import env from "./env";
// import { registerAgents } from "./agents";
// import { EventBus } from "./comms";
// import { privateKeyToAccount } from "viem/accounts";
// import { setupWebSocket } from "./websocket";
// import figlet from "figlet";
import { WebSocket, WebSocketServer } from "ws";
import { EventBus } from "./comms/event-bus";
import { registerAgents } from "./agents";
import { AIFactory } from "./services/ai/factory";
import env from "./env";
import { privateKeyToAccount } from "viem/accounts";
import { mainnet } from "viem/chains";
// import { RecallStorage } from "./agents/plugins/recall-storage/index";
import { HybridStorage } from "./agents/plugins/hybrid-storage/index";
import { ATCPIPProvider } from "./agents/plugins/atcp-ip";
import { SwapAgent } from "./agents/SwapAgent";
import figlet from "figlet";

console.log(figlet.textSync("AVA-TEMPLATE"));
console.log("======== Initializing Server =========");

// // Initialize event bus and agents
// const eventBus = new EventBus();
// const account = privateKeyToAccount(env.PRIVATE_KEY as `0x${string}`);
// export const agents = registerAgents(eventBus, account);

// const PORT = env.PORT || 3001;

// serve(
//   {
//     fetch: app.fetch,
//     port: PORT,
//   },
//   (info) => {
//     console.log(`[🚀] Server running on http://localhost:${info.port}`);
//     console.log(`[👀] Observer agent starting...`);

//     console.log("Event bus", eventBus);
//     // Setup WebSocket server
//     setupWebSocket(eventBus);

//     // agents.observerAgent.start(account.address);
//   }
// );

async function initializeServices() {
  try {
    // Initialize core services
    const eventBus = new EventBus();
    const account = privateKeyToAccount(env.WALLET_PRIVATE_KEY as `0x${string}`);
    
    // Create AI provider
    const aiProvider = AIFactory.createProvider({
      provider: 'groq',
      apiKey: env.GROQ_API_KEY as string,
      modelName: 'gemma2-9b-it'
    });

    // Register minimal set of agents
    console.log("======== Registering agents =========");
    const agents = registerAgents(eventBus, account, aiProvider);
    console.log("[initializeServices] Agents registered");
    
    // Initialize the Swap Agent
    const swapAgent = new SwapAgent();
    console.log("[initializeServices] Swap Agent initialized");

    // Setup WebSocket server
    const WS_PORT = process.env.WS_PORT || 3001;
    const wss = new WebSocketServer({ port: WS_PORT as number });

    wss.on("connection", (ws: WebSocket) => {
      console.log(`[WebSocket] Client connected on port ${WS_PORT}`);
      
      // Register the swap agent to handle WebSocket connections
      swapAgent.handleWebSocketConnection(ws);

      // Forward events from event bus to WebSocket clients
      eventBus.on("agent-action", async (data) => {
        ws.send(JSON.stringify({
          type: "agent-message",
          timestamp: new Date().toLocaleTimeString(),
          role: "assistant",
          content: `[${data.agent}] ${data.action}`,
          agentName: data.agent,
        }));
      });

      eventBus.on("agent-response", async (data) => {
        ws.send(JSON.stringify({
          type: "agent-message",
          timestamp: new Date().toLocaleTimeString(),
          role: "assistant",
          content: data.message,
          agentName: data.agent,
        }));
      });

      eventBus.on("agent-error", async (data) => {
        ws.send(JSON.stringify({
          type: "agent-message",
          timestamp: new Date().toLocaleTimeString(),
          role: "error",
          content: `Error in ${data.agent}: ${data.error}`,
          agentName: data.agent,
        }));
      });

      ws.on("message", async (message: string) => {
        try {
          const data = JSON.parse(message.toString());
          console.log("[WebSocket] Received message:", data);
          
          if (data.type === "settings") {
            // Update AI provider based on settings
            const newProvider = AIFactory.createProvider({
              provider: data.settings.aiProvider.provider,
              apiKey: data.settings.aiProvider.apiKey,
              modelName: data.settings.aiProvider.modelName
            });

            // Update agents with new settings if needed
            if (agents.taskManagerAgent) {
              agents.taskManagerAgent.updateAIProvider?.(newProvider);
            }

            eventBus.emit("agent-action", {
              agent: "system",
              action: "Updated AI provider settings",
            });
          } else if (data.type === "command") {
            // Add user message to chat
            ws.send(JSON.stringify({
              type: "agent-message",
              timestamp: new Date().toLocaleTimeString(),
              role: "user",
              content: data.command,
              agentName: "user",
            }));

            if (data.command === "stop") {
              eventBus.emit("agent-action", {
                agent: "system",
                action: "All agents stopped",
              });
            } else {
              // Process the command
              eventBus.emit("agent-action", {
                agent: "system",
                action: `Processing command: ${data.command}`,
              });
              
              // Create task with basic options
              if (agents.taskManagerAgent) {
                const taskId = await agents.taskManagerAgent.createTask(data.command);
                // Get the task from the task manager and then assign it
                const task = await agents.taskManagerAgent.getTaskById(taskId);
                if (task) {
                  await agents.taskManagerAgent.assignTask(task);
                }
              } else {
                // Fallback if task manager not available
                eventBus.emit("agent-response", {
                  agent: "system",
                  message: `Received command: ${data.command}`,
                });
              }
            }
          }
        } catch (error) {
          console.error("[WebSocket] Error processing message:", error);
          ws.send(JSON.stringify({
            type: "agent-message",
            timestamp: new Date().toLocaleTimeString(),
            role: "error",
            content: "Error processing command",
            agentName: "system",
          }));
        }
      });
    });

    console.log(`[🚀] WebSocket server running on ws://localhost:${WS_PORT}`);
    
  } catch (error) {
    console.error("[initializeServices] Error initializing services:", error);
  }
}

initializeServices().catch(error => {
  console.error("Initialization failed:", error);
});
